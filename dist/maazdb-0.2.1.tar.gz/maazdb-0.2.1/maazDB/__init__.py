# lightdb/__init__.py

from .maazDB import maazDB

__all__ = ["maazDB"]
